﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;

namespace GroceryStore.API.Controllers
{
	using GroceryStore.API.Extensions;
	using GroceryStore.API.Services;
	using GroceryStore.DataAccessLibrary.Models;

	[Route("api/customer")]
	[ApiController]
	public class CustomerController : ControllerBase
	{
		private readonly ILoggerManager _logger;
		private readonly IDataAccessService _daService;
		private readonly IMemoryCache _memoryCache;

		public CustomerController(ILoggerManager logger, IDataAccessService daService, IMemoryCache memoryCache)
		{
			_daService = daService;
			_logger = logger;
			_memoryCache = memoryCache;
		}

		[HttpGet]
		[Route("GetCustomers")]
		public async ValueTask<ActionResult<IEnumerable<CustomerModel>>> GetCustomers()
		{
			try
			{
				var result = await _daService.GetCustomers();
				return Ok(result);
			}
			catch (Exception ex)
			{
				_logger.LogError($"Something went wrong in the {nameof(GetCustomers)} action {ex}");
				return StatusCode(500, $"Internal app error. {ex.Message}");
			}
		}

		[HttpGet]
		[Route("GetCustomerById")]
		public async Task<IActionResult> GetCustomerById(int id)
		{
			try
			{
				var result = await _daService.GetCustomerById(id);
				return Ok(result);
			}
			catch (Exception ex)
			{
				_logger.LogError($"Something went wrong in the {nameof(GetCustomerById)} action {ex}");
				return StatusCode(500, $"Internal app error. {ex.Message}");
			}
		}

		[HttpPost]
		[Route("CreateCustomer")]
		public async Task<IActionResult> CreateCustomer(CustomerModel request)
		{
			try
			{
				var result = await _daService.InsertCustomer(request);
				return Ok(result);
			}
			catch (Exception ex)
			{
				_logger.LogError($"Something went wrong in the {nameof(CreateCustomer)} action {ex}");
				return StatusCode(500, $"Internal app error. {ex.Message}");
			}
		}

		[HttpPut]
		[Route("UpdateCustomer")]
		public async Task<IActionResult> UpdateCustomer(CustomerModel request)
		{
			try
			{
				var result = await _daService.UpdateCustomer(request);
				return Ok(result);
			}
			catch (Exception ex)
			{
				_logger.LogError($"Something went wrong in the {nameof(UpdateCustomer)} action {ex}");
				return StatusCode(500, $"Internal app error. {ex.Message}");
			}
		}
	}
}
