﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GroceryStore.API.Extensions
{
	using GroceryStore.DataAccessLibrary;
	using GroceryStore.DataAccessLibrary.Models;
	public interface IDataAccessService
	{
		ValueTask<List<CustomerModel>> GetCustomers();
		ValueTask<CustomerModel> GetCustomerById(int id);
		ValueTask<CustomerModel> InsertCustomer(CustomerModel customer);
		ValueTask<CustomerModel> UpdateCustomer(CustomerModel customer);
	}

	public class DataAccessService : IDataAccessService
	{
		private protected ICustomersData _customersData;

		public DataAccessService(ICustomersData CustomersData)
		{
			_customersData = CustomersData;
		}
		public ValueTask<List<CustomerModel>> GetCustomers()
		{
			return _customersData.GetCustomers();
		}

		public ValueTask<CustomerModel> GetCustomerById(int id)
		{
			return _customersData.GetCustomerById(id);
		}

		public ValueTask<CustomerModel> InsertCustomer(CustomerModel ob)
		{
			return _customersData.InsertCustomer(ob);
		}

		public ValueTask<CustomerModel> UpdateCustomer(CustomerModel ob)
		{
			return _customersData.UpdateCustomer(ob);
		}
	}
}
