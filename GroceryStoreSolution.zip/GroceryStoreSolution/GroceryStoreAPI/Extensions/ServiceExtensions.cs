﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

namespace GroceryStore.API.Extensions
{
	using GroceryStore.API.Services;
	using GroceryStore.DataAccessLibrary;

	public static class ServiceExtensions
	{
		public static void ConfigureCors(this IServiceCollection services) =>
			services.AddCors(options => options.AddPolicy("CorsPolicy", builder =>
				builder.AllowAnyOrigin()
					.AllowAnyMethod()
					.AllowAnyHeader()));

		public static void ConfigureIisIntegration(this IServiceCollection services) =>
			services.Configure<IISOptions>(options =>
			{
			});

		public static void ConfigureLoggerService(this IServiceCollection services) =>
			services.AddScoped<ILoggerManager, LoggerManager>();
		public static void ConfigureCommonData(this IServiceCollection services) =>
			services.AddScoped<ICustomersData, CustomersData>();

		public static void ConfigureDataAccessService(this IServiceCollection services) =>
			services.AddScoped<IDataAccessService, DataAccessService>();

		public static void ConfigureSqlDataAccess(this IServiceCollection services) =>
			services.AddScoped<ISqlDataAccess, SqlDataAccess>();
	}
}
