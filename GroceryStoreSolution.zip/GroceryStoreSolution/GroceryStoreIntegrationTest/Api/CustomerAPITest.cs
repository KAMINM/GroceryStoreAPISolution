﻿using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;
using Microsoft.AspNetCore.TestHost;
using Microsoft.AspNetCore.Hosting;
using GroceryStore.API;

namespace GroceryStore.IntegrationTest.Api
{
	public class CustomerApiTest
	{
		private readonly HttpClient _client;
		public CustomerApiTest()
		{
			var server = new TestServer(new WebHostBuilder()
				.UseEnvironment("Development")
				.UseStartup<Startup>());
			_client = server.CreateClient();
		}

		[Theory]
		[InlineData("GET")]
		public async Task CustomerGetAllTest(string method)
		{
			var request = new HttpRequestMessage(new HttpMethod(method), "/api/customer/GetCustomers");

			var response = await _client.SendAsync(request);

			Assert.Equal(HttpStatusCode.OK, response.StatusCode);
		}

		[Theory]
		[InlineData("GET", 1)]
		public async Task CustomerGetTest(string method, int? id = null)
		{
			var request = new HttpRequestMessage(new HttpMethod(method), $"/api/customer/GetCustomerById?{id}");

			var response = await _client.SendAsync(request);

			Assert.Equal(HttpStatusCode.OK, response.StatusCode);
		}
	}
}
