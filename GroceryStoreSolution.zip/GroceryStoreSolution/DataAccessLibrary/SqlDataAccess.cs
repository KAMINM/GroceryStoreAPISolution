﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

using Dapper;

using Microsoft.Extensions.Configuration;

namespace GroceryStore.DataAccessLibrary
{
	public interface ISqlDataAccess
    {
        string GetConnection();
        ValueTask<List<T>> LoadData<T, TU>(string sql, TU parameters);
        ValueTask<T> SaveData<T>(string sql, T parameters);
        ValueTask<T> LoadDataScalar<T, TU>(string sql, TU parameters);
        ValueTask<T> LoadDataSingle<T, TU>(string sql, TU parameters);
        ValueTask<List<T>> LoadDataSp<T, TU>(string sql, TU parameters);
        ValueTask SaveDataSp<T>(string sql, T parameters);
    }

    public class SqlDataAccess : ISqlDataAccess
    {
        private readonly IConfiguration _config;

        public string ConnectionStringName { get; set; } = "Default";

        public SqlDataAccess(IConfiguration config)
        {
            _config = config;
        }

        public string GetConnection()
        {
            return _config.GetConnectionString(ConnectionStringName);
        }

        public async ValueTask<T> LoadDataSingle<T, TU>(string sql, TU parameters)
        {
            var connectionString = _config.GetConnectionString(ConnectionStringName);

            using IDbConnection connection = new SqlConnection(connectionString);
            return await connection.QuerySingleAsync<T>(sql, parameters);
        }

        public async ValueTask<T> LoadDataScalar<T, TU>(string sql, TU parameters)
        {
            var connectionString = _config.GetConnectionString(ConnectionStringName);

            using IDbConnection connection = new SqlConnection(connectionString);
            return await connection.ExecuteScalarAsync<T>(sql, parameters);
        }

        public async ValueTask<List<T>> LoadData<T, TU>(string sql, TU parameters)
        {
            var connectionString = _config.GetConnectionString(ConnectionStringName);

            using IDbConnection connection = new SqlConnection(connectionString);
            var data = await connection.QueryAsync<T>(sql, parameters);

            return data.ToList();
        }

        public async ValueTask<T> SaveData<T>(string sql, T parameters)
        {
            var connectionString = _config.GetConnectionString(ConnectionStringName);

            using IDbConnection connection = new SqlConnection(connectionString);
            var data = await connection.QuerySingleAsync<T>(sql, parameters);
            return data;
        }

        public async ValueTask<List<T>> LoadDataSp<T, TU>(string sql, TU parameters)
        {
            var connectionString = _config.GetConnectionString(ConnectionStringName);

            using IDbConnection connection = new SqlConnection(connectionString);
            var data = await connection.QueryAsync<T>(sql, parameters, commandType: CommandType.StoredProcedure);

            return data as List<T>;
        }

        public async ValueTask SaveDataSp<T>(string sql, T parameters)
        {
            var connectionString = _config.GetConnectionString(ConnectionStringName);

            using IDbConnection connection = new SqlConnection(connectionString);
            await connection.ExecuteAsync(sql, parameters, commandType: CommandType.StoredProcedure);
        }
    }
}
