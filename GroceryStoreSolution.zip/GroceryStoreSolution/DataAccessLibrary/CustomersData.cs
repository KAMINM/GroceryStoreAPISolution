﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroceryStore.DataAccessLibrary
{
	using GroceryStore.DataAccessLibrary.Models;
	public interface ICustomersData
	{
		ValueTask<List<CustomerModel>> GetCustomers();
		ValueTask<CustomerModel> GetCustomerById(int Id);
		ValueTask<CustomerModel> InsertCustomer(CustomerModel customer);
		ValueTask<CustomerModel> UpdateCustomer(CustomerModel customer);
		ValueTask<List<CustomerModel>> GetCustomersSp();
		ValueTask<List<CustomerModel>> GetCustomersWithParam(string sql, Dapper.DynamicParameters p);
	}
    public class CustomersData: ICustomersData
	{
		private readonly ISqlDataAccess _db;

		public CustomersData(ISqlDataAccess db)
		{
			_db = db;
		}

		public ValueTask<List<CustomerModel>> GetCustomersWithParam(string sql, Dapper.DynamicParameters p)
		{
			return _db.LoadData<CustomerModel, dynamic>(sql, p);
		}

		public ValueTask<List<CustomerModel>> GetCustomers()
		{
			var sql = "select * from Test.Customers";

			return _db.LoadData<CustomerModel, dynamic>(sql, new { });
		}

		public ValueTask<CustomerModel> GetCustomerById(int id)
		{
			var sql = $"select * from Test.Customers WHERE Id={id};";

			return _db.LoadDataSingle<CustomerModel, dynamic>(sql, new { });
		}

		public ValueTask<CustomerModel> InsertCustomer(CustomerModel customer)
		{
			var sql = @"INSERT INTO Test.Customers (FirstName, LastName) values (@FirstName, @LastName);";

			return _db.SaveData(sql, customer);
		}

		public ValueTask<CustomerModel> UpdateCustomer(CustomerModel customer)
		{
			var sql = $@"UPDATE Test.Customers SET Name={customer.Name},Modified={DateTime.Now}) 
						 WHERE Id={customer.Id};";

			return _db.SaveData(sql, customer);
		}

		public ValueTask<List<CustomerModel>> GetCustomersSp()
		{
			var sql = "Test.GetCustomers";

			return _db.LoadDataSp<CustomerModel, dynamic>(sql, new { });
		}
	}
}
