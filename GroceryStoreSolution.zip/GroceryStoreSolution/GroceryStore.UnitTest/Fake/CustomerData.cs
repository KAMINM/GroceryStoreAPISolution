﻿using System.Collections.Generic;

namespace GroceryStore.UnitTest.Fake
{
	using GroceryStore.DataAccessLibrary.Models;
	public class CustomerData
	{
		public List<CustomerModel> GetCustomers()
		{
			var customerlVm = new List<CustomerModel>
			{
				new CustomerModel
				{
					Id = 1,
					Name = "Bob"
				},
				new CustomerModel
				{
					Id = 2,
					Name = "Mary"
				},
				new CustomerModel
				{
					Id = 3,
					Name = "Joe"
				}
			};

			return customerlVm;
		}
	}
}
