﻿using System.Collections.Generic;
using System.Linq;

using Xunit;

namespace GroceryStore.UnitTest.Repository
{
	using GroceryStore.API.Controllers;
	using GroceryStore.API.Extensions;
	using GroceryStore.DataAccessLibrary.Models;
	using GroceryStore.UnitTest.Fake;
	public class CustomerRepositoryTest
	{
		[Fact]
		public void CustomerGetAll()
		{
			var mockRepo = new Moq.Mock<IDataAccessService>();
			mockRepo.Setup(repo => repo.GetCustomers().Result).Returns(new CustomerData().GetCustomers());
			var controller = new CustomerController(null, mockRepo.Object, null);

			var result = controller.GetCustomers();

			// Assert
			var viewResult = Assert.IsType<Microsoft.AspNetCore.Mvc.OkObjectResult>(result);
			var model = Assert.IsAssignableFrom<List<CustomerModel>>(viewResult.Value);
			Assert.NotNull(model);
			Assert.Equal(2, model.Count());
		}
	}
}
